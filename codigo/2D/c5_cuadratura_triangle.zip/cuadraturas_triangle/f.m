function z = f(x,y)
% Tomada de: http://math2.uncc.edu/~shaodeng/TEACHING/math5172/2010Spring/        

z = 2 - x - 2*y;
return;

end
